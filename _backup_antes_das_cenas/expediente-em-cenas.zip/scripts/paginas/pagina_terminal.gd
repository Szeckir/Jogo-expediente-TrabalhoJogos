extends Pagina

# Terminal do setor 02: minijogo de três rodadas de "ache o intruso".
# A página tem cinco estados (nós Cota, Intro, Rodada, Vitoria e
# Recusa na cena); só um fica visível por vez.

var _rodada := 0
var _intruso := -1

@onready var _estados: Array[Control] = [%Cota, %Intro, %Rodada, %Vitoria, %Recusa]
@onready var _premio: Label = %Premio
@onready var _usadas: Label = %Usadas
@onready var _contador: Label = %Contador
@onready var _enunciado: Label = %Enunciado
@onready var _opcoes: HBoxContainer = %Opcoes
@onready var _creditado: Label = %Creditado


func _ready() -> void:
	%Iniciar.pressed.connect(_iniciar_partida)
	%Voltar.pressed.connect(_mostrar_intro)
	for botao in _opcoes.get_children():
		botao.pressed.connect(_responder.bind(botao))


func ao_abrir(_movel: Movel) -> void:
	_mostrar_intro()


func _mostrar(estado: Control) -> void:
	for e in _estados:
		e.visible = (e == estado)


func _mostrar_intro() -> void:
	if Estado.partidas_terminal >= Estado.COTA_PARTIDAS:
		_mostrar(%Cota)
		return
	_premio.text = "Três rodadas seguidas. Prêmio: " + str(Estado.PREMIO_PARTIDA) + " fichas."
	_usadas.text = "Partidas usadas: " + str(Estado.partidas_terminal) + " de " + str(Estado.COTA_PARTIDAS)
	_mostrar(%Intro)
	Estado.anotar("O terminal do setor 02 paga fichas por partida vencida.")


func _iniciar_partida() -> void:
	Estado.partidas_terminal += 1
	_rodada = 0
	_proxima_rodada()


func _proxima_rodada() -> void:
	if _rodada >= 3:
		Estado.ganhar_fichas(Estado.PREMIO_PARTIDA)
		_creditado.text = "Creditado: " + str(Estado.PREMIO_PARTIDA) + " fichas."
		_mostrar(%Vitoria)
		Estado.riscar("O terminal do setor 02 paga fichas por partida vencida.")
		return

	var rodada := _gerar_rodada()
	_contador.text = "RODADA " + str(_rodada + 1) + " DE 3"
	_enunciado.text = rodada["texto"]
	_intruso = rodada["intruso"]

	var valores: Array = rodada["opcoes"]
	for i in _opcoes.get_child_count():
		_opcoes.get_child(i).text = str(valores[i])
	_mostrar(%Rodada)


func _gerar_rodada() -> Dictionary:
	var tipo := randi() % 5
	var opcoes: Array = []
	var intruso := 0

	match tipo:
		0:
			var quadrados := [4, 9, 16, 25, 36, 49, 64, 81, 100, 121]
			quadrados.shuffle()
			opcoes = [quadrados[0], quadrados[1], quadrados[2]]
			intruso = int(quadrados[0]) + 3
			return {"texto": "Três são quadrados perfeitos. Marque o intruso.",
				"opcoes": _embaralhar(opcoes, intruso), "intruso": intruso}
		1:
			var base := (randi() % 20 + 3) * 5
			opcoes = [base, base + 5, base + 15]
			intruso = base + 7
			return {"texto": "Três são múltiplos de cinco. Marque o intruso.",
				"opcoes": _embaralhar(opcoes, intruso), "intruso": intruso}
		2:
			var p := (randi() % 30 + 5) * 2
			opcoes = [p, p + 2, p + 6]
			intruso = p + 3
			return {"texto": "Três são pares. Marque o intruso.",
				"opcoes": _embaralhar(opcoes, intruso), "intruso": intruso}
		3:
			var primos := [11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]
			primos.shuffle()
			opcoes = [primos[0], primos[1], primos[2]]
			intruso = int(primos[0]) + 1
			return {"texto": "Três são primos. Marque o intruso.",
				"opcoes": _embaralhar(opcoes, intruso), "intruso": intruso}
		_:
			var b := randi() % 7 + 2
			opcoes = [b * 3, b * 3 + 3, b * 3 + 9]
			intruso = b * 3 + 2
			return {"texto": "Três são múltiplos de três. Marque o intruso.",
				"opcoes": _embaralhar(opcoes, intruso), "intruso": intruso}


func _embaralhar(opcoes: Array, intruso: int) -> Array:
	var todas := opcoes.duplicate()
	todas.append(intruso)
	todas.shuffle()
	return todas


func _responder(botao: Button) -> void:
	if int(botao.text) == _intruso:
		Audio.tocar("aceito")
		_rodada += 1
		_proxima_rodada()
	else:
		Audio.tocar("recusado")
		_mostrar(%Recusa)
